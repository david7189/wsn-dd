#ifndef __QUERY_PLAN_H__

#define __QUERY_PLAN_H__

enum {NULL_EVAL_EPOCH = 65535};

enum
{ 
	AM_Frag2_Frag1Site1_txSite8 = 20,
 	AM_DELIVERMESSAGE = 24
,
 	AM_Frag2_Frag1Site1_txSite6 = 22
,
 	AM_Frag2_Frag1Site1_txSite3 = 21
,
 	AM_Frag2_Frag1Site1_txSite2 = 23

}; 


// Tuple output type for operator 3
// uk.ac.manchester.cs.snee.operators.sensornet.SensornetDeliverOperator@2d6e8792
// size = 16 bytes

typedef struct TupleFrag1 {
	uint16_t evalEpoch;
	uint16_t mistream_epoch;
	uint16_t mistream_id;
	float mistream_pressure;
} TupleFrag1;

typedef TupleFrag1* TupleFrag1Ptr;


// Tuple output type for operator 5
// uk.ac.manchester.cs.snee.operators.sensornet.SensornetAcquireOperator@2acf57e3
// size = 16 bytes

typedef struct TupleFrag2 {
	uint16_t evalEpoch;
	uint16_t mistream_epoch;
	uint16_t mistream_id;
	float mistream_pressure;
} TupleFrag2;

typedef TupleFrag2* TupleFrag2Ptr;



// Message output type for Fragment 2 (operator 6)
typedef struct MessageFrag2 {
	TupleFrag2 tuples[2];
}MessageFrag2;

typedef MessageFrag2 *MessageFrag2Ptr;



typedef struct DeliverMessage {
	TupleFrag2 tuples[2];
} DeliverMessage;

typedef DeliverMessage* DeliverMessagePtr;



#endif


