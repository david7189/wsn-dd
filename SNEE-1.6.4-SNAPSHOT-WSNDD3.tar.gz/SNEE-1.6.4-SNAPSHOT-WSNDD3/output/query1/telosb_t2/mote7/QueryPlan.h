#ifndef __QUERY_PLAN_H__

#define __QUERY_PLAN_H__

enum {NULL_EVAL_EPOCH = 65535};

enum
{ 
	AM_Frag2_Frag1Site1_txSite9 = 28,
 	AM_Frag2_Frag1Site1_txSite8 = 23
,
 	AM_Frag2_Frag1Site1_txSite7 = 25
,
 	AM_DELIVERMESSAGE = 31
,
 	AM_Frag2_Frag1Site1_txSite10 = 27
,
 	AM_Frag2_Frag1Site1_txSite5 = 20
,
 	AM_Frag2_Frag1Site1_txSite11 = 30
,
 	AM_Frag2_Frag1Site1_txSite4 = 22
,
 	AM_Frag2_Frag1Site1_txSite3 = 26
,
 	AM_Frag2_Frag1Site1_txSite2 = 24
,
 	AM_Frag2_Frag1Site1_txSite14 = 29
,
 	AM_Frag2_Frag1Site1_txSite15 = 21

}; 


// Tuple output type for operator 3
// uk.ac.manchester.cs.snee.operators.sensornet.SensornetDeliverOperator@39ba5a14
// size = 16 bytes

typedef struct TupleFrag1 {
	uint16_t evalEpoch;
	uint16_t brook_epoch;
	uint16_t brook_id;
	float brook_depth;
} TupleFrag1;

typedef TupleFrag1* TupleFrag1Ptr;


// Tuple output type for operator 5
// uk.ac.manchester.cs.snee.operators.sensornet.SensornetAcquireOperator@340f438e
// size = 16 bytes

typedef struct TupleFrag2 {
	uint16_t evalEpoch;
	uint16_t brook_epoch;
	uint16_t brook_id;
	float brook_depth;
} TupleFrag2;

typedef TupleFrag2* TupleFrag2Ptr;



// Message output type for Fragment 2 (operator 6)
typedef struct MessageFrag2 {
	TupleFrag2 tuples[2];
}MessageFrag2;

typedef MessageFrag2 *MessageFrag2Ptr;



typedef struct DeliverMessage {
	TupleFrag2 tuples[2];
} DeliverMessage;

typedef DeliverMessage* DeliverMessagePtr;



#endif


